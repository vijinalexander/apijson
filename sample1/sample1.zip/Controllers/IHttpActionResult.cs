﻿namespace sample1.Controllers
{
    public interface IHttpActionResult
    {
    }
}